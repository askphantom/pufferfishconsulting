This directory provides examples for specific use cases. Please [open an issue](https://github.com/sendgrid/smtpapi-php/issues) or make a pull request for any use cases you would like to see here. Thank you!

# Table of Contents
